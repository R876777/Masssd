import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"
import { PatientService } from "@/lib/services/patientService"
import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    // التحقق من الصلاحيات
    if (!user.permissions?.includes("patients.read")) {
      return NextResponse.json({ error: "ليس لديك صلاحية لعرض المرضى" }, { status: 403 })
    }

    await connectToDatabase()
    const patientService = new PatientService()

    const url = new URL(request.url)
    const search = url.searchParams.get("search")
    const page = Number.parseInt(url.searchParams.get("page") || "1")
    const limit = Number.parseInt(url.searchParams.get("limit") || "20")
    const status = url.searchParams.get("status")
    const gender = url.searchParams.get("gender")

    let result

    if (search) {
      // البحث في المرضى
      const patients = await patientService.searchPatients(search, limit)
      result = {
        patients,
        total: patients.length,
        page: 1,
        totalPages: 1,
      }
    } else {
      // جلب جميع المرضى مع التصفية
      const filters: any = {}
      if (status) filters.status = status
      if (gender) filters.gender = gender

      result = await patientService.getAllPatients(page, limit, filters)
    }

    return NextResponse.json(result)
  } catch (error) {
    console.error("Get patients error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    // التحقق من الصلاحيات
    if (!user.permissions?.includes("patients.create")) {
      return NextResponse.json({ error: "ليس لديك صلاحية لإضافة مرضى" }, { status: 403 })
    }

    await connectToDatabase()
    const patientService = new PatientService()

    const patientData = await request.json()

    // التحقق من البيانات المطلوبة
    if (!patientData.name || !patientData.phone || !patientData.dateOfBirth) {
      return NextResponse.json({ error: "الاسم ورقم الهاتف وتاريخ الميلاد مطلوبة" }, { status: 400 })
    }

    // تحويل تاريخ الميلاد إلى Date object
    patientData.dateOfBirth = new Date(patientData.dateOfBirth)

    const newPatient = await patientService.createPatient(patientData, new ObjectId(user.userId))

    return NextResponse.json(
      {
        patient: {
          ...newPatient,
          _id: newPatient._id!.toString(),
        },
        message: "تم إضافة المريض بنجاح",
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Create patient error:", error)

    if (error instanceof Error && error.message.includes("موجود")) {
      return NextResponse.json({ error: error.message }, { status: 409 })
    }

    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
