import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"
import { PatientService } from "@/lib/services/patientService"
import { connectToDatabase } from "@/lib/mongodb"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    if (!user.permissions?.includes("patients.read")) {
      return NextResponse.json({ error: "ليس لديك صلاحية لعرض إحصائيات المرضى" }, { status: 403 })
    }

    await connectToDatabase()
    const patientService = new PatientService()

    const stats = await patientService.getPatientStats()

    return NextResponse.json(stats)
  } catch (error) {
    console.error("Get patient stats error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
