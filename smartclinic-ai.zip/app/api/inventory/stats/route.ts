import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    if (!user.permissions?.includes("inventory.read")) {
      return NextResponse.json({ error: "ليس لديك صلاحية لعرض إحصائيات المخزون" }, { status: 403 })
    }

    const { db } = await connectToDatabase()
    const inventoryCollection = db.collection("inventory")

    const now = new Date()
    const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000)

    const [totalItems, lowStockCount, expiringSoonCount] = await Promise.all([
      inventoryCollection.countDocuments(),
      inventoryCollection.countDocuments({
        $expr: { $lte: ["$currentStock", "$minStock"] },
      }),
      inventoryCollection.countDocuments({
        expiryDate: { $lte: thirtyDaysFromNow, $gte: now },
      }),
    ])

    return NextResponse.json({
      totalItems,
      lowStock: lowStockCount,
      expiringSoon: expiringSoonCount,
    })
  } catch (error) {
    console.error("Get inventory stats error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
