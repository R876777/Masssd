import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"

// محاكاة قاعدة بيانات المخزون
const inventory = [
  {
    id: "1",
    name: "باراسيتامول 500mg",
    category: "مسكنات",
    type: "دواء",
    currentStock: 150,
    minStock: 50,
    maxStock: 500,
    unit: "قرص",
    price: 0.5,
    supplier: "شركة الأدوية المتحدة",
    expiryDate: "2025-12-31",
    batchNumber: "PAR2024001",
    location: "رف A-1",
    status: "available",
    lastUpdated: new Date("2024-01-15"),
  },
  {
    id: "2",
    name: "أملوديبين 5mg",
    category: "أدوية القلب",
    type: "دواء",
    currentStock: 25,
    minStock: 30,
    maxStock: 200,
    unit: "قرص",
    price: 1.2,
    supplier: "شركة الأدوية المتحدة",
    expiryDate: "2024-06-30",
    batchNumber: "AML2024001",
    location: "رف B-2",
    status: "low_stock",
    lastUpdated: new Date("2024-01-10"),
  },
  {
    id: "3",
    name: "سرنجة 5ml",
    category: "مستلزمات طبية",
    type: "معدات",
    currentStock: 500,
    minStock: 100,
    maxStock: 1000,
    unit: "قطعة",
    price: 0.3,
    supplier: "شركة المعدات الطبية",
    expiryDate: "2026-01-01",
    batchNumber: "SYR2024001",
    location: "رف C-1",
    status: "available",
    lastUpdated: new Date("2024-01-12"),
  },
  {
    id: "4",
    name: "إنسولين",
    category: "أدوية السكري",
    type: "دواء",
    currentStock: 5,
    minStock: 10,
    maxStock: 50,
    unit: "قلم",
    price: 25.0,
    supplier: "شركة الأدوية المتخصصة",
    expiryDate: "2024-03-15",
    batchNumber: "INS2024001",
    location: "ثلاجة A",
    status: "critical",
    lastUpdated: new Date("2024-01-14"),
  },
]

export async function GET(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const url = new URL(request.url)
    const category = url.searchParams.get("category")
    const status = url.searchParams.get("status")
    const search = url.searchParams.get("search")

    let filteredInventory = inventory

    // تصفية حسب الفئة
    if (category) {
      filteredInventory = filteredInventory.filter((item) => item.category === category)
    }

    // تصفية حسب الحالة
    if (status) {
      filteredInventory = filteredInventory.filter((item) => item.status === status)
    }

    // البحث
    if (search) {
      filteredInventory = filteredInventory.filter(
        (item) =>
          item.name.toLowerCase().includes(search.toLowerCase()) ||
          item.category.toLowerCase().includes(search.toLowerCase()),
      )
    }

    // إحصائيات المخزون
    const stats = {
      total: inventory.length,
      available: inventory.filter((item) => item.status === "available").length,
      lowStock: inventory.filter((item) => item.status === "low_stock").length,
      critical: inventory.filter((item) => item.status === "critical").length,
      expired: inventory.filter((item) => new Date(item.expiryDate) < new Date()).length,
    }

    return NextResponse.json({
      inventory: filteredInventory,
      stats,
    })
  } catch (error) {
    console.error("Get inventory error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const itemData = await request.json()

    // تحديد حالة المخزون
    let status = "available"
    if (itemData.currentStock <= itemData.minStock * 0.5) {
      status = "critical"
    } else if (itemData.currentStock <= itemData.minStock) {
      status = "low_stock"
    }

    const newItem = {
      id: (inventory.length + 1).toString(),
      ...itemData,
      status,
      lastUpdated: new Date(),
    }

    inventory.push(newItem)

    return NextResponse.json(
      {
        item: newItem,
        message: "تم إضافة العنصر بنجاح",
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Create inventory item error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
