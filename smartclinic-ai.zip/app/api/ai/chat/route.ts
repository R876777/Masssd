import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"

// محاكاة الذكاء الاصطناعي - في الإنتاج سيتم استخدام OpenAI أو Claude
const generateAIResponse = async (message: string, language = "ar"): Promise<string> => {
  const lowerMessage = message.toLowerCase()

  // قاعدة معرفة طبية بسيطة
  const medicalKnowledge = {
    ar: {
      صداع: "الصداع يمكن أن يكون بسبب التوتر، قلة النوم، أو الجفاف. يُنصح بالراحة وشرب الماء. إذا استمر، راجع الطبيب.",
      حمى: "الحمى علامة على مقاومة الجسم للعدوى. اشرب السوائل واستريح. إذا تجاوزت 38.5°، راجع الطبيب.",
      ضغط: "ضغط الدم المرتفع يتطلب متابعة طبية منتظمة. تجنب الملح والتوتر ومارس الرياضة.",
      سكري: "السكري يتطلب مراقبة مستوى السكر والالتزام بالدواء والنظام الغذائي.",
      موعد: "يمكنك حجز موعد من خلال نظام المواعيد أو الاتصال على 02-1234567",
      ساعات: "ساعات العمل: الأحد-الخميس 8:00ص-8:00م، الجمعة 8:00ص-12:00م",
      طوارئ: "في حالات الطوارئ اتصل على 101 أو توجه لأقرب مستشفى",
    },
    en: {
      headache:
        "Headaches can be caused by stress, lack of sleep, or dehydration. Rest and drink water. If persistent, see a doctor.",
      fever: "Fever is a sign of the body fighting infection. Drink fluids and rest. If over 38.5°C, see a doctor.",
      pressure: "High blood pressure requires regular medical follow-up. Avoid salt and stress, exercise regularly.",
      diabetes: "Diabetes requires monitoring blood sugar levels and adhering to medication and diet.",
      appointment: "You can book an appointment through the appointment system or call 02-1234567",
      hours: "Working hours: Sunday-Thursday 8:00AM-8:00PM, Friday 8:00AM-12:00PM",
      emergency: "For emergencies call 101 or go to the nearest hospital",
    },
  }

  const knowledge = medicalKnowledge[language as keyof typeof medicalKnowledge] || medicalKnowledge.ar

  // البحث عن إجابة مناسبة
  for (const [keyword, response] of Object.entries(knowledge)) {
    if (lowerMessage.includes(keyword)) {
      return response
    }
  }

  // إجابة افتراضية
  if (language === "ar") {
    return "شكراً لسؤالك. يمكنني مساعدتك في الاستفسارات الطبية العامة، حجز المواعيد، أو معلومات العيادة. هل يمكنك توضيح سؤالك أكثر؟"
  } else {
    return "Thank you for your question. I can help with general medical inquiries, appointment booking, or clinic information. Could you please clarify your question?"
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const { message, language = "ar" } = await request.json()

    if (!message) {
      return NextResponse.json({ error: "الرسالة مطلوبة" }, { status: 400 })
    }

    // محاكاة وقت المعالجة
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const response = await generateAIResponse(message, language)

    // اقتراحات ذكية بناءً على السياق
    const suggestions =
      language === "ar"
        ? ["حجز موعد", "معلومات التأمين", "ساعات العمل", "أرقام الطوارئ"]
        : ["Book appointment", "Insurance info", "Working hours", "Emergency numbers"]

    return NextResponse.json({
      response,
      suggestions,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("AI Chat error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
