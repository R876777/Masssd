import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    if (!user.permissions?.includes("financial.read")) {
      return NextResponse.json({ error: "ليس لديك صلاحية لعرض الإحصائيات المالية" }, { status: 403 })
    }

    const { db } = await connectToDatabase()
    const invoicesCollection = db.collection("invoices")

    const now = new Date()
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000)
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)

    // إحصائيات اليوم
    const todayRevenue = await invoicesCollection
      .aggregate([
        {
          $match: {
            status: "paid",
            paymentDate: { $gte: startOfDay, $lt: endOfDay },
          },
        },
        {
          $group: {
            _id: null,
            total: { $sum: "$total" },
          },
        },
      ])
      .toArray()

    // إحصائيات الشهر
    const monthlyRevenue = await invoicesCollection
      .aggregate([
        {
          $match: {
            status: "paid",
            paymentDate: { $gte: startOfMonth },
          },
        },
        {
          $group: {
            _id: null,
            total: { $sum: "$total" },
          },
        },
      ])
      .toArray()

    // الدفعات المعلقة
    const pendingPayments = await invoicesCollection.countDocuments({
      status: { $in: ["sent", "overdue"] },
    })

    return NextResponse.json({
      todayRevenue: todayRevenue[0]?.total || 0,
      monthlyRevenue: monthlyRevenue[0]?.total || 0,
      pendingPayments,
    })
  } catch (error) {
    console.error("Get financial stats error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
