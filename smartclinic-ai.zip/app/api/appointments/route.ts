import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"

// محاكاة قاعدة بيانات المواعيد
const appointments = [
  {
    id: "1",
    patientId: "1",
    patientName: "أحمد محمد علي",
    doctorId: "2",
    doctorName: "د. سارة أحمد",
    date: "2024-01-15",
    time: "09:00",
    duration: 30,
    type: "استشارة عامة",
    status: "confirmed",
    priority: "normal",
    reason: "فحص دوري",
    notes: "مريض منتظم، آخر زيارة قبل 3 أشهر",
    createdAt: new Date("2024-01-10"),
    updatedAt: new Date("2024-01-10"),
  },
  {
    id: "2",
    patientId: "2",
    patientName: "فاطمة حسن",
    doctorId: "2",
    doctorName: "د. سارة أحمد",
    date: "2024-01-15",
    time: "09:30",
    duration: 45,
    type: "متابعة",
    status: "pending",
    priority: "high",
    reason: "متابعة ضغط الدم",
    notes: "يحتاج فحص ضغط الدم وتعديل الدواء",
    createdAt: new Date("2024-01-12"),
    updatedAt: new Date("2024-01-12"),
  },
]

export async function GET(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const url = new URL(request.url)
    const date = url.searchParams.get("date")
    const doctorId = url.searchParams.get("doctorId")
    const status = url.searchParams.get("status")

    let filteredAppointments = appointments

    // تصفية حسب التاريخ
    if (date) {
      filteredAppointments = filteredAppointments.filter((apt) => apt.date === date)
    }

    // تصفية حسب الطبيب
    if (doctorId) {
      filteredAppointments = filteredAppointments.filter((apt) => apt.doctorId === doctorId)
    }

    // تصفية حسب الحالة
    if (status) {
      filteredAppointments = filteredAppointments.filter((apt) => apt.status === status)
    }

    // ترتيب حسب الوقت
    filteredAppointments.sort((a, b) => {
      const timeA = new Date(`${a.date} ${a.time}`)
      const timeB = new Date(`${b.date} ${b.time}`)
      return timeA.getTime() - timeB.getTime()
    })

    return NextResponse.json({
      appointments: filteredAppointments,
      total: filteredAppointments.length,
    })
  } catch (error) {
    console.error("Get appointments error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    const appointmentData = await request.json()

    // التحقق من تضارب المواعيد
    const conflictingAppointment = appointments.find(
      (apt) =>
        apt.doctorId === appointmentData.doctorId &&
        apt.date === appointmentData.date &&
        apt.time === appointmentData.time &&
        apt.status !== "cancelled",
    )

    if (conflictingAppointment) {
      return NextResponse.json({ error: "يوجد موعد آخر في نفس الوقت" }, { status: 409 })
    }

    const newAppointment = {
      id: (appointments.length + 1).toString(),
      ...appointmentData,
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    appointments.push(newAppointment)

    return NextResponse.json(
      {
        appointment: newAppointment,
        message: "تم حجز الموعد بنجاح",
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Create appointment error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
