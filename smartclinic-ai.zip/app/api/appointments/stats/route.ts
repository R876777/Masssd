import { type NextRequest, NextResponse } from "next/server"
import { verifyToken } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"

export async function GET(request: NextRequest) {
  try {
    const user = await verifyToken(request)
    if (!user) {
      return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
    }

    if (!user.permissions?.includes("appointments.read")) {
      return NextResponse.json({ error: "ليس لديك صلاحية لعرض إحصائيات المواعيد" }, { status: 403 })
    }

    const { db } = await connectToDatabase()
    const appointmentsCollection = db.collection("appointments")

    const now = new Date()
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate())
    const endOfDay = new Date(startOfDay.getTime() + 24 * 60 * 60 * 1000)

    const startOfWeek = new Date(startOfDay)
    startOfWeek.setDate(startOfDay.getDate() - startOfDay.getDay())
    const endOfWeek = new Date(startOfWeek.getTime() + 7 * 24 * 60 * 60 * 1000)

    const [todayCount, weekCount, pendingCount, completedCount] = await Promise.all([
      appointmentsCollection.countDocuments({
        date: { $gte: startOfDay, $lt: endOfDay },
      }),
      appointmentsCollection.countDocuments({
        date: { $gte: startOfWeek, $lt: endOfWeek },
      }),
      appointmentsCollection.countDocuments({
        status: { $in: ["scheduled", "confirmed"] },
      }),
      appointmentsCollection.countDocuments({
        status: "completed",
      }),
    ])

    return NextResponse.json({
      today: todayCount,
      thisWeek: weekCount,
      pending: pendingCount,
      completed: completedCount,
    })
  } catch (error) {
    console.error("Get appointment stats error:", error)
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 })
  }
}
