import { connectToDatabase } from "@/lib/mongodb"
import { PatientService } from "@/lib/services/patientService"
import { UserService } from "@/lib/services/userService"
import { ObjectId } from "mongodb"

async function seedData() {
  try {
    console.log("🌱 بدء إضافة البيانات التجريبية...")

    const { db } = await connectToDatabase()
    const patientService = new PatientService()
    const userService = new UserService()

    // الحصول على معرف الطبيب للربط
    const doctor = await userService.getUserByEmail("doctor@clinic.com")
    if (!doctor) {
      throw new Error("لم يتم العثور على الطبيب")
    }

    // إضافة مرضى تجريبيين
    console.log("👥 إضافة مرضى تجريبيين...")

    const samplePatients = [
      {
        name: "أحمد محمد علي",
        email: "ahmed.ali@example.com",
        phone: "0599123456",
        dateOfBirth: new Date("1985-03-15"),
        gender: "male" as const,
        bloodType: "A+",
        address: "شارع الجامعة، رام الله",
        city: "رام الله",
        country: "فلسطين",
        nationalId: "123456789",
        emergencyContact: {
          name: "فاطمة علي",
          phone: "0598765432",
          relation: "زوجة",
        },
        insurance: {
          company: "شركة التأمين الوطنية",
          policyNumber: "INS001234",
          expiryDate: new Date("2025-12-31"),
        },
        allergies: ["البنسلين"],
        chronicDiseases: ["ارتفاع ضغط الدم", "السكري النوع الثاني"],
        notes: "مريض منتظم في المتابعة",
      },
      {
        name: "فاطمة حسن محمود",
        email: "fatima.hassan@example.com",
        phone: "0598765432",
        dateOfBirth: new Date("1992-08-22"),
        gender: "female" as const,
        bloodType: "O-",
        address: "حي الشرق، نابلس",
        city: "نابلس",
        country: "فلسطين",
        nationalId: "987654321",
        emergencyContact: {
          name: "محمد حسن",
          phone: "0597654321",
          relation: "زوج",
        },
        allergies: ["لا توجد حساسية معروفة"],
        chronicDiseases: [],
        notes: "حامل - الشهر السادس",
      },
      {
        name: "محمد عبد الله سالم",
        email: "mohammed.salem@example.com",
        phone: "0597654321",
        dateOfBirth: new Date("1978-12-10"),
        gender: "male" as const,
        bloodType: "B+",
        address: "البلدة القديمة، القدس",
        city: "القدس",
        country: "فلسطين",
        nationalId: "456789123",
        emergencyContact: {
          name: "سارة سالم",
          phone: "0596543210",
          relation: "ابنة",
        },
        allergies: ["الأسبرين", "المكسرات"],
        chronicDiseases: ["الربو"],
        notes: "يحتاج متابعة دورية للربو",
      },
      {
        name: "سارة أحمد قاسم",
        email: "sara.qasem@example.com",
        phone: "0596543210",
        dateOfBirth: new Date("2000-05-18"),
        gender: "female" as const,
        bloodType: "AB+",
        address: "شارع النصر، غزة",
        city: "غزة",
        country: "فلسطين",
        nationalId: "789123456",
        emergencyContact: {
          name: "أحمد قاسم",
          phone: "0595432109",
          relation: "والد",
        },
        allergies: [],
        chronicDiseases: [],
        notes: "طالبة جامعية - فحص دوري",
      },
      {
        name: "عبد الرحمن يوسف",
        email: "abdulrahman.youssef@example.com",
        phone: "0595432109",
        dateOfBirth: new Date("1965-11-30"),
        gender: "male" as const,
        bloodType: "O+",
        address: "حي الزهراء، الخليل",
        city: "الخليل",
        country: "فلسطين",
        nationalId: "321654987",
        emergencyContact: {
          name: "أم محمد",
          phone: "0594321098",
          relation: "زوجة",
        },
        allergies: ["اليود"],
        chronicDiseases: ["أمراض القلب", "ارتفاع الكوليسترول"],
        notes: "مريض قلب - يحتاج متابعة حثيثة",
      },
    ]

    const createdPatients = []
    for (const patientData of samplePatients) {
      try {
        const patient = await patientService.createPatient(patientData, doctor._id!)
        createdPatients.push(patient)
        console.log(`✅ تم إضافة المريض: ${patient.name}`)
      } catch (error) {
        console.log(`⚠️ المريض ${patientData.name} موجود بالفعل`)
      }
    }

    // إضافة سجلات طبية تجريبية
    console.log("📋 إضافة سجلات طبية تجريبية...")

    const medicalRecords = [
      {
        patientId: createdPatients[0]._id!.toString(),
        record: {
          date: new Date("2024-01-15"),
          diagnosis: "ارتفاع ضغط الدم المزمن",
          treatment: "دواء أملوديبين 5mg + نظام غذائي قليل الملح",
          doctorId: doctor._id!,
          doctorName: doctor.name,
          symptoms: ["صداع", "دوخة", "تعب عام"],
          vitalSigns: {
            temperature: 36.8,
            bloodPressure: { systolic: 150, diastolic: 95 },
            heartRate: 78,
            weight: 85,
            height: 175,
          },
          prescriptions: [
            {
              medicationName: "أملوديبين",
              dosage: "5mg",
              frequency: "مرة واحدة يومياً",
              duration: "شهر واحد",
              instructions: "يؤخذ صباحاً مع الطعام",
              quantity: 30,
            },
          ],
          labTests: [],
          notes: "المريض يستجيب جيداً للعلاج. ينصح بالمتابعة الدورية",
          followUpDate: new Date("2024-02-15"),
        },
      },
      {
        patientId: createdPatients[1]._id!.toString(),
        record: {
          date: new Date("2024-01-20"),
          diagnosis: "متابعة حمل طبيعي - الشهر السادس",
          treatment: "فيتامينات الحمل + حمض الفوليك",
          doctorId: doctor._id!,
          doctorName: doctor.name,
          symptoms: ["غثيان خفيف", "تعب"],
          vitalSigns: {
            temperature: 36.6,
            bloodPressure: { systolic: 120, diastolic: 80 },
            heartRate: 85,
            weight: 68,
            height: 165,
          },
          prescriptions: [
            {
              medicationName: "فيتامينات الحمل",
              dosage: "قرص واحد",
              frequency: "مرة واحدة يومياً",
              duration: "حتى نهاية الحمل",
              instructions: "يؤخذ مع الطعام",
              quantity: 30,
            },
          ],
          labTests: [],
          notes: "الحمل يسير بشكل طبيعي. الجنين في وضع جيد",
          followUpDate: new Date("2024-02-20"),
        },
      },
    ]

    if (createdPatients.length > 0) {
      for (const { patientId, record } of medicalRecords) {
        await patientService.addMedicalRecord(patientId, record)
        console.log(`✅ تم إضافة سجل طبي للمريض`)
      }
    }

    // إضافة مواعيد تجريبية
    console.log("📅 إضافة مواعيد تجريبية...")

    const appointmentsCollection = db.collection("appointments")

    const sampleAppointments = [
      {
        appointmentId: `APT${Date.now()}001`,
        patientId: createdPatients[0]?._id || new ObjectId(),
        patientName: createdPatients[0]?.name || "أحمد محمد علي",
        patientPhone: createdPatients[0]?.phone || "0599123456",
        doctorId: doctor._id!,
        doctorName: doctor.name,
        date: new Date("2024-02-15"),
        time: "09:00",
        duration: 30,
        type: "follow_up" as const,
        status: "scheduled" as const,
        priority: "normal" as const,
        reason: "متابعة ضغط الدم",
        symptoms: [],
        notes: "فحص دوري لمتابعة ضغط الدم",
        reminderSent: false,
        paymentStatus: "pending" as const,
        amount: 100,
        currency: "YER",
        room: "101",
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: doctor._id!,
      },
      {
        appointmentId: `APT${Date.now()}002`,
        patientId: createdPatients[1]?._id || new ObjectId(),
        patientName: createdPatients[1]?.name || "فاطمة حسن محمود",
        patientPhone: createdPatients[1]?.phone || "0598765432",
        doctorId: doctor._id!,
        doctorName: doctor.name,
        date: new Date("2024-02-16"),
        time: "10:30",
        duration: 45,
        type: "consultation" as const,
        status: "confirmed" as const,
        priority: "normal" as const,
        reason: "متابعة الحمل",
        symptoms: [],
        notes: "فحص شهري للحمل",
        reminderSent: true,
        paymentStatus: "insurance_covered" as const,
        amount: 150,
        currency: "YER",
        room: "102",
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: doctor._id!,
      },
      {
        appointmentId: `APT${Date.now()}003`,
        patientId: createdPatients[2]?._id || new ObjectId(),
        patientName: createdPatients[2]?.name || "محمد عبد الله سالم",
        patientPhone: createdPatients[2]?.phone || "0597654321",
        doctorId: doctor._id!,
        doctorName: doctor.name,
        date: new Date("2024-02-17"),
        time: "14:00",
        duration: 30,
        type: "checkup" as const,
        status: "scheduled" as const,
        priority: "high" as const,
        reason: "متابعة الربو",
        symptoms: ["ضيق تنفس", "سعال"],
        notes: "تقييم حالة الربو وتعديل العلاج",
        reminderSent: false,
        paymentStatus: "pending" as const,
        amount: 120,
        currency: "YER",
        room: "103",
        createdAt: new Date(),
        updatedAt: new Date(),
        createdBy: doctor._id!,
      },
    ]

    for (const appointment of sampleAppointments) {
      try {
        await appointmentsCollection.insertOne(appointment)
        console.log(`✅ تم إضافة موعد: ${appointment.patientName}`)
      } catch (error) {
        console.log(`⚠️ خطأ في إضافة موعد: ${appointment.patientName}`)
      }
    }

    // إضافة عناصر مخزون تجريبية
    console.log("📦 إضافة عناصر مخزون تجريبية...")

    const inventoryCollection = db.collection("inventory")

    const sampleInventory = [
      {
        itemId: `INV${Date.now()}001`,
        name: "Paracetamol 500mg",
        arabicName: "باراسيتامول 500 ملغ",
        category: "مسكنات الألم",
        type: "medication",
        currentStock: 500,
        minStock: 50,
        maxStock: 1000,
        unit: "قرص",
        price: 0.5,
        currency: "YER",
        supplier: {
          name: "شركة الأدوية الوطنية",
          contact: "0599888777",
          email: "info@national-pharma.com",
          phone: "0599888777",
        },
        manufacturer: "National Pharmaceuticals",
        expiryDate: new Date("2025-12-31"),
        batchNumber: "PAR2024001",
        location: "رف A1",
        barcode: "1234567890123",
        description: "مسكن للألم وخافض للحرارة",
        instructions: "يؤخذ عند الحاجة، لا يزيد عن 4 أقراص يومياً",
        sideEffects: ["غثيان نادر", "طفح جلدي نادر"],
        contraindications: ["حساسية للباراسيتامول", "أمراض الكبد الشديدة"],
        status: "available",
        transactions: [
          {
            type: "in",
            quantity: 500,
            reason: "شراء جديد",
            reference: "PO-2024-001",
            performedBy: doctor._id!,
            performedByName: doctor.name,
            date: new Date("2024-01-01"),
            notes: "دفعة جديدة من المورد",
          },
        ],
        lastUpdated: new Date(),
        createdAt: new Date(),
        createdBy: doctor._id!,
      },
      {
        itemId: `INV${Date.now()}002`,
        name: "Amoxicillin 250mg",
        arabicName: "أموكسيسيلين 250 ملغ",
        category: "مضادات حيوية",
        type: "medication",
        currentStock: 200,
        minStock: 30,
        maxStock: 500,
        unit: "كبسولة",
        price: 2.0,
        currency: "YER",
        supplier: {
          name: "شركة الأدوية المتقدمة",
          contact: "0598777666",
          email: "sales@advanced-pharma.com",
          phone: "0598777666",
        },
        manufacturer: "Advanced Pharmaceuticals",
        expiryDate: new Date("2025-06-30"),
        batchNumber: "AMX2024002",
        location: "رف B2",
        barcode: "2345678901234",
        description: "مضاد حيوي واسع الطيف",
        instructions: "يؤخذ كل 8 ساعات مع الطعام",
        sideEffects: ["إسهال", "غثيان", "طفح جلدي"],
        contraindications: ["حساسية للبنسلين", "الحمل والرضاعة"],
        status: "available",
        transactions: [
          {
            type: "in",
            quantity: 200,
            reason: "شراء جديد",
            reference: "PO-2024-002",
            performedBy: doctor._id!,
            performedByName: doctor.name,
            date: new Date("2024-01-05"),
            notes: "مضاد حيوي للعدوى البكتيرية",
          },
        ],
        lastUpdated: new Date(),
        createdAt: new Date(),
        createdBy: doctor._id!,
      },
      {
        itemId: `INV${Date.now()}003`,
        name: "Digital Thermometer",
        arabicName: "ميزان حرارة رقمي",
        category: "أجهزة طبية",
        type: "equipment",
        currentStock: 15,
        minStock: 5,
        maxStock: 30,
        unit: "جهاز",
        price: 25.0,
        currency: "YER",
        supplier: {
          name: "شركة الأجهزة الطبية",
          contact: "0597666555",
          email: "info@medical-devices.com",
          phone: "0597666555",
        },
        manufacturer: "MedTech Solutions",
        location: "خزانة المعدات",
        barcode: "3456789012345",
        description: "ميزان حرارة رقمي دقيق",
        instructions: "للاستخدام الفموي أو تحت الإبط",
        status: "available",
        transactions: [
          {
            type: "in",
            quantity: 15,
            reason: "شراء جديد",
            reference: "PO-2024-003",
            performedBy: doctor._id!,
            performedByName: doctor.name,
            date: new Date("2024-01-10"),
            notes: "أجهزة قياس الحرارة للعيادات",
          },
        ],
        lastUpdated: new Date(),
        createdAt: new Date(),
        createdBy: doctor._id!,
      },
    ]

    for (const item of sampleInventory) {
      try {
        await inventoryCollection.insertOne(item)
        console.log(`✅ تم إضافة عنصر مخزون: ${item.arabicName}`)
      } catch (error) {
        console.log(`⚠️ خطأ في إضافة عنصر: ${item.arabicName}`)
      }
    }

    console.log("🎉 تم إضافة جميع البيانات التجريبية بنجاح!")
    console.log("")
    console.log("📊 ملخص البيانات المضافة:")
    console.log(`👥 المرضى: ${createdPatients.length}`)
    console.log(`📅 المواعيد: ${sampleAppointments.length}`)
    console.log(`📦 عناصر المخزون: ${sampleInventory.length}`)
    console.log(`📋 السجلات الطبية: ${medicalRecords.length}`)
  } catch (error) {
    console.error("❌ خطأ في إضافة البيانات التجريبية:", error)
    process.exit(1)
  }
}

// تشغيل الإعداد إذا تم استدعاء الملف مباشرة
if (require.main === module) {
  seedData()
}

export default seedData
