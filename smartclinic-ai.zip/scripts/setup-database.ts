import { connectToDatabase } from "@/lib/mongodb"
import { UserService } from "@/lib/services/userService"

async function setupDatabase() {
  try {
    console.log("🔄 بدء إعداد قاعدة البيانات...")

    const { db } = await connectToDatabase()

    // إنشاء الفهارس
    console.log("📊 إنشاء الفهارس...")

    // فهارس المستخدمين
    await db.collection("users").createIndex({ email: 1 }, { unique: true })
    await db.collection("users").createIndex({ role: 1 })
    await db.collection("users").createIndex({ isActive: 1 })

    // فهارس المرضى
    await db.collection("patients").createIndex({ patientId: 1 }, { unique: true })
    await db.collection("patients").createIndex({ phone: 1 })
    await db.collection("patients").createIndex({ email: 1 })
    await db.collection("patients").createIndex({ nationalId: 1 })
    await db.collection("patients").createIndex({ name: "text", phone: "text", email: "text" })

    // فهارس المواعيد
    await db.collection("appointments").createIndex({ appointmentId: 1 }, { unique: true })
    await db.collection("appointments").createIndex({ patientId: 1 })
    await db.collection("appointments").createIndex({ doctorId: 1 })
    await db.collection("appointments").createIndex({ date: 1, time: 1 })
    await db.collection("appointments").createIndex({ status: 1 })

    // فهارس المخزون
    await db.collection("inventory").createIndex({ itemId: 1 }, { unique: true })
    await db.collection("inventory").createIndex({ name: "text", arabicName: "text" })
    await db.collection("inventory").createIndex({ category: 1 })
    await db.collection("inventory").createIndex({ status: 1 })
    await db.collection("inventory").createIndex({ expiryDate: 1 })

    // فهارس المختبر
    await db.collection("labtests").createIndex({ testId: 1 }, { unique: true })
    await db.collection("labtests").createIndex({ patientId: 1 })
    await db.collection("labtests").createIndex({ doctorId: 1 })
    await db.collection("labtests").createIndex({ status: 1 })
    await db.collection("labtests").createIndex({ requestDate: 1 })

    // فهارس الفواتير
    await db.collection("invoices").createIndex({ invoiceId: 1 }, { unique: true })
    await db.collection("invoices").createIndex({ patientId: 1 })
    await db.collection("invoices").createIndex({ status: 1 })
    await db.collection("invoices").createIndex({ dueDate: 1 })

    console.log("✅ تم إنشاء الفهارس بنجاح")

    // إنشاء المستخدم الإداري الافتراضي
    console.log("👤 إنشاء المستخدم الإداري...")

    const userService = new UserService()

    // التحقق من وجود مستخدم إداري
    const existingAdmin = await userService.getUserByEmail("admin@clinic.com")

    if (!existingAdmin) {
      await userService.createUser({
        name: "مدير النظام",
        email: "admin@clinic.com",
        password: "admin123",
        role: "admin",
        specialization: "إدارة النظام",
        department: "الإدارة",
        phone: "0599123456",
      })

      console.log("✅ تم إنشاء المستخدم الإداري")
      console.log("📧 البريد: admin@clinic.com")
      console.log("🔑 كلمة المرور: admin123")
    } else {
      console.log("ℹ️ المستخدم الإداري موجود بالفعل")
    }

    // إنشاء مستخدمين تجريبيين آخرين
    const testUsers = [
      {
        name: "د. سارة أحمد",
        email: "doctor@clinic.com",
        password: "doctor123",
        role: "doctor" as const,
        specialization: "طب عام",
        department: "العيادات الخارجية",
        phone: "0598765432",
      },
      {
        name: "فاطمة علي",
        email: "nurse@clinic.com",
        password: "nurse123",
        role: "nurse" as const,
        specialization: "تمريض عام",
        department: "التمريض",
        phone: "0597654321",
      },
      {
        name: "محمد حسن",
        email: "reception@clinic.com",
        password: "reception123",
        role: "receptionist" as const,
        specialization: "استقبال",
        department: "الاستقبال",
        phone: "0596543210",
      },
    ]

    for (const userData of testUsers) {
      const existingUser = await userService.getUserByEmail(userData.email)
      if (!existingUser) {
        await userService.createUser(userData)
        console.log(`✅ تم إنشاء المستخدم: ${userData.name}`)
      }
    }

    console.log("🎉 تم إعداد قاعدة البيانات بنجاح!")
    console.log("")
    console.log("📋 الحسابات التجريبية:")
    console.log("1. مدير النظام: admin@clinic.com / admin123")
    console.log("2. طبيب: doctor@clinic.com / doctor123")
    console.log("3. ممرض/ة: nurse@clinic.com / nurse123")
    console.log("4. استقبال: reception@clinic.com / reception123")
  } catch (error) {
    console.error("❌ خطأ في إعداد قاعدة البيانات:", error)
    process.exit(1)
  }
}

// تشغيل الإعداد إذا تم استدعاء الملف مباشرة
if (require.main === module) {
  setupDatabase()
}

export default setupDatabase
